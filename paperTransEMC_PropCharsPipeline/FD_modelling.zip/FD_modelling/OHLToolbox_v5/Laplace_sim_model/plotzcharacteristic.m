format long;

semilogx(freq,abs(Zmodal_ch(:,1)),freq,abs(Zmodal_ch(:,2)),freq,abs(Zmodal_ch(:,3)))