# ULMAtp
 This repository presents the support files for implementing ULM in ATP. Please read the User Manual_ULM-ATP_v2.00.pdf for instructions. 
 Users are free to use all support files and codes available for non-commercial activities, but are kindly requested to include reference to the following paper:

Felipe O.S. Zanon, Osis E.S. Leal, Alberto De Conti, "Implementation of the universal line model in the alternative transients program", Electric Power Systems Research, vol. 197, p. 107311, Aug. 2021, doi: 10.1016/j.epsr.2021.107311. 
